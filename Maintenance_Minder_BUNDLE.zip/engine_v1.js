/* EP26 — FIRST DRAFT (prompt 1). NOT THE TOOL. Kept so viewers can see the wrong build.
   Faithful to what the first prompt produced: a calendar-only board.
   Its habits: every interval is read as DAYS (the meter column too); "last service" is the
   last matching ROW IN THE FILE, not the latest date; rows it cannot parse are skipped
   silently; duplicates are counted twice; an asset with no history simply never appears. */
(function (root) {
  "use strict";
  function days(iso) {
    var t = Date.parse((iso || "").trim());
    return isNaN(t) ? null : Math.floor(t / 86400000);
  }
  function csv(text) {
    return (text || "").replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); })
      .map(function (l) { return l.split(",").map(function (c) { return c.replace(/^"|"$/g, "").trim(); }); });
  }
  function run(assetsText, scheduleText, historyText, settings) {
    settings = settings || {};
    var asOf = days(settings.asOf || "2026-11-09");
    var a = csv(assetsText), s = csv(scheduleText), h = csv(historyText);
    var names = {};
    a.slice(1).forEach(function (r) { names[r[0]] = r[1]; });
    var last = {}, cost = {};
    h.slice(1).forEach(function (r) {
      var d = days(r[0]);
      if (d === null) return;                       // silent skip
      var key = r[1] + "|" + r[2];
      last[key] = { date: d, raw: r[0] };           // last ROW wins, not latest date
      var amt = parseFloat((r[4] || "0").replace(/[$,]/g, ""));
      if (!isNaN(amt)) cost[r[1]] = (cost[r[1]] || 0) + amt;  // duplicates counted twice
    });
    var board = [];
    s.slice(1).forEach(function (r) {
      var asset = r[0], task = r[1];
      var interval = parseInt(r[2] || r[3], 10);    // the meter column read as DAYS
      var k = asset + "|" + task;
      if (!last[k]) return;                         // never-serviced pair: invisible
      var due = last[k].date + interval;
      var left = due - asOf;
      board.push({ asset: asset, name: names[asset] || "", task: task,
        status: left < 0 ? "OVERDUE" : "OK", daysLeft: left });
    });
    board.sort(function (x, y) { return x.daysLeft - y.daysLeft; });
    var total = 0; Object.keys(cost).forEach(function (k) { total += cost[k]; });
    return { board: board, costByAsset: cost, costTotal: Math.round(total * 100) / 100,
      overdue: board.filter(function (b) { return b.status === "OVERDUE"; }).length };
  }
  var api = { run: run };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.MinderV1 = api;
})(typeof self !== "undefined" ? self : this);
