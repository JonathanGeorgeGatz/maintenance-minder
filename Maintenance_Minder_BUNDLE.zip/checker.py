#!/usr/bin/env python3
"""EP26 — independent checker. Implements SPEC.md from the spec text alone.
Reads three CSV files + settings JSON, prints the output object as JSON."""
import sys, json, csv, io, datetime

def epoch_days(s):
    try:
        y, m, d = s.split("-")
        if len(y) != 4 or len(m) != 2 or len(d) != 2: return None
        dt = datetime.date(int(y), int(m), int(d))
        if dt.year < 2000 or dt.year > 2099: return None
        return (dt - datetime.date(1970, 1, 1)).days
    except Exception:
        return None

def iso(days):
    return (datetime.date(1970, 1, 1) + datetime.timedelta(days=days)).isoformat()

def ceil_div(a, b):
    return (a + b - 1) // b

def parse_cents(raw):
    s = (raw or "").strip().replace("$", "").replace(",", "")
    if s == "": return 0
    import re
    if not re.fullmatch(r"\d+(\.\d{1,2})?", s): return None
    if "." in s:
        a, b = s.split(".")
        return int(a) * 100 + int((b + "00")[:2])
    return int(s) * 100

def parse_meter(raw):
    s = (raw or "").strip().replace(",", "")
    if s == "": return "blank"
    if not s.isdigit(): return "bad"
    return int(s)

def rows_of(text):
    out = []
    for r in csv.reader(io.StringIO(text)):
        if any((c or "").strip() != "" for c in r): out.append(r)
    return out

def hmap(header, names):
    m = {(h or "").strip().lower(): i for i, h in enumerate(header)}
    return {k: m.get(v, -1) for k, v in names.items()}

def cell(row, idx):
    return (row[idx].strip() if 0 <= idx < len(row) else "")

def run(assets_text, schedule_text, history_text, settings):
    as_of_iso = settings.get("asOf", "2026-11-09")
    due_soon = int(settings.get("dueSoonDays", 14))
    window = int(settings.get("rateWindowDays", 90))
    cost_year = int(settings.get("costYear", 2026))
    as_of = epoch_days(as_of_iso)
    config = []
    if as_of is None: config.append('settings: bad asOf "%s"' % as_of_iso)

    a_rows = rows_of(assets_text)
    ah = hmap(a_rows[0] if a_rows else [], dict(id="asset", name="name", unit="unit", cm="current meter", md="meter date", insvc="in service", mas="meter at start"))
    assets, order = {}, []
    for i in range(1, len(a_rows)):
        r = a_rows[i]
        aid = cell(r, ah["id"])
        if not aid: config.append("asset row %d: missing id" % i); continue
        unit = cell(r, ah["unit"]).lower()
        if unit not in ("miles", "hours", "none"): config.append('asset row %d: bad unit "%s"' % (i, cell(r, ah["unit"]))); continue
        insvc = epoch_days(cell(r, ah["insvc"]))
        if insvc is None: config.append('asset row %d: bad in-service date "%s"' % (i, cell(r, ah["insvc"]))); continue
        cm = md = mas = None
        if unit != "none":
            cm = parse_meter(cell(r, ah["cm"]))
            md = epoch_days(cell(r, ah["md"]))
            mas = parse_meter(cell(r, ah["mas"]))
            if mas == "blank": mas = 0
            if cm in ("blank", "bad") or md is None or mas == "bad":
                config.append("asset row %d: bad meter fields" % i); continue
        assets[aid] = dict(id=aid, unit=unit, cm=cm, md=md, insvc=insvc, mas=mas, readings=[])
        order.append(aid)

    s_rows = rows_of(schedule_text)
    sh = hmap(s_rows[0] if s_rows else [], dict(id="asset", task="task", ed="every days", em="every meter"))
    rules = []
    for i in range(1, len(s_rows)):
        r = s_rows[i]
        aid, task = cell(r, sh["id"]), cell(r, sh["task"])
        if aid not in assets: config.append('schedule row %d: unknown asset "%s"' % (i, aid)); continue
        ed_raw, em_raw = cell(r, sh["ed"]), cell(r, sh["em"])
        ed = None if ed_raw == "" else (int(ed_raw) if ed_raw.isdigit() else "bad")
        em = None if em_raw == "" else (int(em_raw) if em_raw.isdigit() else "bad")
        if ed == "bad" or em == "bad" or (ed is None and em is None) or ed == 0 or em == 0:
            config.append("schedule row %d: no usable interval" % i); continue
        if em is not None and assets[aid]["unit"] == "none":
            config.append("schedule row %d: meter interval on a no-meter asset" % i); continue
        rules.append(dict(asset=aid, task=task, ed=ed, em=em))

    h_rows = rows_of(history_text)
    hh = hmap(h_rows[0] if h_rows else [], dict(date="date", id="asset", task="task", meter="meter", cost="cost", notes="notes"))
    rule_set = set((ru["asset"], ru["task"]) for ru in rules)
    counted, unsched, dups, refused = [], [], [], []
    seen = set()
    for i in range(1, len(h_rows)):
        r = h_rows[i]
        date_raw, aid, task = cell(r, hh["date"]), cell(r, hh["id"]), cell(r, hh["task"])
        meter_raw, cost_raw, notes = cell(r, hh["meter"]), cell(r, hh["cost"]), cell(r, hh["notes"])
        d = epoch_days(date_raw)
        if d is None: refused.append(dict(row=i, reason='bad date "%s"' % date_raw)); continue
        cents = parse_cents(cost_raw)
        if cents is None: refused.append(dict(row=i, reason='bad amount "%s"' % cost_raw)); continue
        if aid not in assets: refused.append(dict(row=i, reason='unknown asset "%s"' % aid)); continue
        a = assets[aid]
        meter = parse_meter(meter_raw)
        if meter == "bad": refused.append(dict(row=i, reason='bad meter "%s"' % meter_raw)); continue
        if meter != "blank" and a["unit"] != "none":
            bad = None
            for rd in a["readings"]:
                if rd[0] <= d and rd[1] > meter: bad = (meter, rd[1]); break
                if rd[0] >= d and rd[1] < meter: bad = (rd[1], meter); break
            if bad:
                refused.append(dict(row=i, reason="meter goes backwards (%d after %d)" % bad)); continue
        key = (date_raw, aid, task, "" if meter == "blank" else meter, cents)
        if key in seen: dups.append(i); continue
        seen.add(key)
        rec = dict(row=i, date=d, asset=aid, task=task, meter=(None if meter == "blank" else meter), cents=cents, notes=notes)
        if meter != "blank" and a["unit"] != "none": a["readings"].append((d, meter, i))
        if (aid, task) in rule_set: counted.append(rec)
        else: unsched.append(rec)

    for aid in order:
        a = assets[aid]
        if a["unit"] != "none" and a["cm"] is not None and a["md"] is not None:
            a["readings"].append((a["md"], a["cm"], -1))
        a["readings"].sort(key=lambda x: (x[0], x[1]))

    rates = {}
    for aid in order:
        a = assets[aid]
        if a["unit"] == "none": rates[aid] = None; continue
        w = [x for x in a["readings"] if as_of - window <= x[0] <= as_of]
        if len(w) < 2: rates[aid] = None; continue
        delta, span = w[-1][1] - w[0][1], w[-1][0] - w[0][0]
        rates[aid] = dict(delta=delta, span=span) if delta > 0 and span >= 1 else None

    board = []
    for ru in rules:
        a = assets[ru["asset"]]
        best = None
        for c in counted:
            if c["asset"] != ru["asset"] or c["task"] != ru["task"]: continue
            if best is None: best = c; continue
            cm_ = -1 if c["meter"] is None else c["meter"]
            bm = -1 if best["meter"] is None else best["meter"]
            if (c["date"], cm_, c["row"]) > (best["date"], bm, best["row"]): best = c
        from_insvc = best is None
        last_date = best["date"] if best else a["insvc"]
        basis_est = False
        if a["unit"] == "none": last_meter = None
        elif best and best["meter"] is not None: last_meter = best["meter"]
        elif best:
            basis_est = True
            cands = [x[1] for x in a["readings"] if x[0] <= last_date]
            last_meter = max(cands) if cands else a["mas"]
        else: last_meter = a["mas"]

        date_due = last_date + ru["ed"] if ru["ed"] is not None else None
        days_to_date = date_due - as_of if date_due is not None else None
        date_over = date_due is not None and as_of >= date_due
        meter_due = remaining = None
        meter_over = False
        if ru["em"] is not None and a["unit"] != "none":
            meter_due = last_meter + ru["em"]
            remaining = meter_due - a["cm"]
            meter_over = a["cm"] >= meter_due
        proj = days_left = over_days = over_meter = None
        if date_over or meter_over:
            status = "OVERDUE"
            if date_over: over_days = as_of - date_due
            if meter_over: over_meter = a["cm"] - meter_due
        elif meter_due is not None and not rates[ru["asset"]]:
            status = "NEEDS A METER READING"
        else:
            opts = []
            if days_to_date is not None: opts.append(days_to_date)
            if meter_due is not None:
                proj = ceil_div(remaining * rates[ru["asset"]]["span"], rates[ru["asset"]]["delta"])
                opts.append(proj)
            days_left = min(opts)
            status = "DUE SOON" if days_left <= due_soon else "OK"
        board.append(dict(asset=ru["asset"], task=ru["task"], status=status, fromInService=from_insvc,
                          meterBasisEstimated=basis_est, lastDate=iso(last_date), lastMeter=last_meter,
                          dateDue=iso(date_due) if date_due is not None else None, meterDue=meter_due,
                          daysToDate=days_to_date, remaining=remaining, projDays=proj, daysLeft=days_left,
                          overdueDays=over_days, overdueMeter=over_meter))
    rank = {"OVERDUE": 0, "NEEDS A METER READING": 1, "DUE SOON": 2, "OK": 3}
    board.sort(key=lambda b: (rank[b["status"]], 10**9 if b["daysLeft"] is None else b["daysLeft"], b["asset"], b["task"]))

    def in_year(d): return iso(d)[:4] == str(cost_year)
    money = {aid: dict(asset=aid, plannedCents=0, unplannedCents=0, totalCents=0) for aid in order}
    for c in counted:
        if in_year(c["date"]): money[c["asset"]]["plannedCents"] += c["cents"]
    for c in unsched:
        if in_year(c["date"]): money[c["asset"]]["unplannedCents"] += c["cents"]
    money_arr, money_total = [], 0
    for aid in order:
        m = money[aid]; m["totalCents"] = m["plannedCents"] + m["unplannedCents"]; money_total += m["totalCents"]
        if m["totalCents"] > 0: money_arr.append(m)
    money_arr.sort(key=lambda m: (-m["totalCents"], m["asset"]))

    total_rows = len(counted) + len(unsched) + len(dups) + len(refused)
    straight = sum(c["cents"] for c in counted + unsched if in_year(c["date"]))
    rows_tie = total_rows == len(h_rows) - 1
    money_tie = straight == money_total
    share_ok = len(refused) * 100 <= total_rows * 5
    trusted = rows_tie and money_tie and share_ok and not config
    return dict(board=board, rates=rates, money=money_arr, moneyTotalCents=money_total,
                counted=len(counted), unscheduled=len(unsched), duplicates=len(dups),
                refused=refused,
                unscheduledRows=[dict(row=c["row"], asset=c["asset"], date=iso(c["date"]), costCents=c["cents"], notes=c["notes"], task=c["task"]) for c in unsched],
                duplicateRows=list(dups), configRefusals=config, totalRows=total_rows,
                trusted=trusted, banner=None if trusted else "DO NOT TRUST THIS SERVICE BOARD")

if __name__ == "__main__":
    assets_text = open(sys.argv[1]).read()
    schedule_text = open(sys.argv[2]).read()
    history_text = open(sys.argv[3]).read()
    settings = json.loads(sys.argv[4]) if len(sys.argv) > 4 else {}
    print(json.dumps(run(assets_text, schedule_text, history_text, settings), indent=1, sort_keys=True))
