/* EP26 — SECOND DRAFT (prompt 2). NOT THE TOOL. Kept so viewers can see the wrong build.
   Given the real rules, it still carries three habits the checker caught:
   (a) "whichever comes first" implemented as whichever comes LAST — a rule is overdue only
       when BOTH the date clock AND the meter have run out (AND instead of OR);
   (b) usage rate from the asset's WHOLE LIFE (current meter since in-service), not recent use;
   (c) a blank meter cell is read as 0 — so a service logged without a reading becomes a
       zero reading, trips its own backwards check, and the row is thrown away. */
(function (root) {
  "use strict";
  function epochDays(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec((iso || "").trim());
    if (!m) return null;
    var t = Date.UTC(+m[1], +m[2] - 1, +m[3]);
    var dt = new Date(t);
    if (dt.getUTCMonth() !== +m[2] - 1 || dt.getUTCDate() !== +m[3]) return null;
    return Math.floor(t / 86400000);
  }
  function csv(text) {
    return (text || "").replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); })
      .map(function (l) {
        var out = [], cur = "", q = false;
        for (var i = 0; i < l.length; i++) {
          var c = l[i];
          if (q) { if (c === '"') q = false; else cur += c; }
          else if (c === '"') q = true;
          else if (c === ",") { out.push(cur.trim()); cur = ""; }
          else cur += c;
        }
        out.push(cur.trim());
        return out;
      });
  }
  function run(assetsText, scheduleText, historyText, settings) {
    settings = settings || {};
    var asOf = epochDays(settings.asOf || "2026-11-09");
    var dueSoonDays = settings.dueSoonDays != null ? +settings.dueSoonDays : 14;
    var a = csv(assetsText), s = csv(scheduleText), h = csv(historyText);
    var assets = {};
    a.slice(1).forEach(function (r) {
      assets[r[0]] = { id: r[0], name: r[1], unit: (r[2] || "").toLowerCase(),
        cm: parseInt(r[3] || "0", 10) || 0, md: epochDays(r[4]),
        insvc: epochDays(r[5]), mas: parseInt(r[6] || "0", 10) || 0, maxMeter: -1 };
    });
    var counted = [], unsched = [], refused = [], seen = {};
    var ruleKey = {};
    s.slice(1).forEach(function (r) { ruleKey[r[0] + "|" + r[1]] = true; });
    h.slice(1).forEach(function (r, idx) {
      var d = epochDays(r[0]);
      if (d === null) { refused.push({ row: idx + 1, reason: 'bad date "' + r[0] + '"' }); return; }
      var amt = (r[4] || "").replace(/[$,]/g, "");
      var cents = amt === "" ? 0 : (/^\d+(\.\d{1,2})?$/.test(amt) ? Math.round(parseFloat(amt) * 100) : null);
      if (cents === null) { refused.push({ row: idx + 1, reason: 'bad amount "' + r[4] + '"' }); return; }
      var asset = assets[r[1]];
      if (!asset) { refused.push({ row: idx + 1, reason: 'unknown asset "' + r[1] + '"' }); return; }
      var meter = parseInt(r[3] || "0", 10) || 0;      // (c) blank = 0
      if (asset.unit !== "none") {
        if (meter < asset.maxMeter) {                  // its own backwards check — the 0 trips it
          refused.push({ row: idx + 1, reason: "meter goes backwards (" + meter + " after " + asset.maxMeter + ")" });
          return;
        }
        asset.maxMeter = Math.max(asset.maxMeter, meter);
      }
      var key = [r[0], r[1], r[2], meter, cents].join("|");
      if (seen[key]) return;                            // duplicate parked
      seen[key] = true;
      var rec = { row: idx + 1, date: d, asset: r[1], task: r[2], meter: meter, cents: cents };
      if (ruleKey[r[1] + "|" + r[2]]) counted.push(rec); else unsched.push(rec);
    });
    var board = [];
    s.slice(1).forEach(function (r) {
      var asset = assets[r[0]]; if (!asset) return;
      var ed = r[2] === "" ? null : parseInt(r[2], 10);
      var em = r[3] === "" ? null : parseInt(r[3], 10);
      var best = null;
      counted.forEach(function (c) {
        if (c.asset !== r[0] || c.task !== r[1]) return;
        if (!best || c.date > best.date) best = c;
      });
      var lastDate = best ? best.date : asset.insvc;
      var lastMeter = best ? best.meter : asset.mas;
      var dateDue = ed !== null ? lastDate + ed : null;
      var meterDue = em !== null && asset.unit !== "none" ? lastMeter + em : null;
      var dateOver = dateDue !== null && asOf >= dateDue;
      var meterOver = meterDue !== null && asset.cm >= meterDue;
      // (a) AND instead of OR: only overdue when every clock that exists has run out
      var over = (dateDue !== null ? dateOver : true) && (meterDue !== null ? meterOver : true);
      var status, daysLeft = null;
      if (over) status = "OVERDUE";
      else {
        var opts = [];
        if (dateDue !== null) opts.push(dateDue - asOf);
        if (meterDue !== null) {
          // (b) lifetime average: current meter over the asset's whole life
          var lifeDays = Math.max(1, (asset.md || asOf) - asset.insvc);
          var perDay = (asset.cm - asset.mas) / lifeDays;
          opts.push(perDay > 0 ? Math.ceil((meterDue - asset.cm) / perDay) : 9999);
        }
        daysLeft = Math.min.apply(null, opts);
        status = daysLeft <= dueSoonDays ? "DUE SOON" : "OK";
      }
      board.push({ asset: r[0], task: r[1], status: status, daysLeft: daysLeft,
        lastDate: lastDate, lastMeter: lastMeter, dateDue: dateDue, meterDue: meterDue });
    });
    var money = {}, total = 0;
    counted.concat(unsched).forEach(function (c) {
      if (new Date(c.date * 86400000).getUTCFullYear() !== (settings.costYear != null ? +settings.costYear : 2026)) return;
      money[c.asset] = (money[c.asset] || 0) + c.cents; total += c.cents;
    });
    return { board: board, refused: refused, counted: counted.length, unscheduled: unsched.length,
      moneyByAsset: money, moneyTotalCents: total,
      overdue: board.filter(function (b) { return b.status === "OVERDUE"; }).length };
  }
  var api = { run: run };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.MinderV2 = api;
})(typeof self !== "undefined" ? self : this);
